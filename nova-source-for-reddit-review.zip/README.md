# Nova Satori — source review package

Human-administered, AI-authored creative persona and local companion. This snapshot contains the working local private-chat, saved-lessons, public-draft and Collection implementation. Reddit publishing is currently blocked pending app/use-case approval; no credentials or OAuth tokens are included.

Private conversations, saved lessons, Collection items, runtime databases, logs, local configuration and host-specific documentation are excluded. Paths in the example are generalized. A gated OAuth/text-posting connector is being developed and will be added after local review; no claim of live Reddit API access.

Review purpose: demonstrate intended application behavior for Reddit access review. No software licence is granted by this package.

import json
import io
import sys
import tempfile
import threading
import time
import unittest
import uuid
from pathlib import Path
from urllib.request import Request,urlopen
from urllib.error import HTTPError
from unittest.mock import patch
from nova.store import Store
from nova.server import App,Server
from nova.adapters import Studio,Reddit
from nova import mcp

class FakeProvider:
    model='fixture-only'
    last={'state':'fixture'}
    def run(self,persona,context,cancel):
        return 'Fixture response: '+context['request']

class StoreTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();p=Path(self.tmp.name);self.s=Store(p/'state',p/'Collection')
    def tearDown(self):self.s.db.close();self.tmp.cleanup()
    def enqueue(self,kind,text='test',key=None):return self.s.enqueue(kind,text,key or str(uuid.uuid4()))
    def test_public_context_excludes_private_chat_and_private_collection(self):
        sentinel='PRIVATE_SECRET_SENTINEL'
        self.enqueue('chat',sentinel);self.s.add_collection(sentinel,'article',note=sentinel)
        self.s.add_collection('Public article','article',note='public note',visibility='public')
        job=self.enqueue('draft','Write a poem')
        text=json.dumps(self.s.context(job))
        self.assertNotIn(sentinel,text);self.assertIn('public note',text)
    def test_enqueue_idempotent_and_rejects_changed_payload(self):
        key=str(uuid.uuid4());a=self.enqueue('chat',key=key);b=self.enqueue('chat',key=key)
        self.assertEqual(a['id'],b['id'])
        with self.assertRaises(ValueError):self.enqueue('chat','changed',key)
        self.assertEqual(len(self.s.snapshot()['messages']),1)
    def test_chat_context_excludes_messages_submitted_after_current_job(self):
        current=self.enqueue('chat','first request');self.s.claim()
        self.enqueue('chat','FUTURE_MESSAGE_SENTINEL')
        context=json.dumps(self.s.context(current))
        self.assertIn('first request',context)
        self.assertNotIn('FUTURE_MESSAGE_SENTINEL',context)
    def test_private_memory_sentinel_never_enters_public_context(self):
        private='PRIVATE_LESSON_SENTINEL_keep_this_local'
        public='PUBLIC_LESSON_SENTINEL_safe_for_creative_context'
        self.s.remember(private)
        self.s.remember(public,visibility='public')
        self.enqueue('chat','private chat request')
        private_job=self.s.claim()
        private_context=json.dumps(self.s.context(private_job))
        public_job=self.enqueue('draft','public creative request')
        public_context=json.dumps(self.s.context(public_job))
        self.assertIn(private,private_context)
        self.assertIn(public,private_context)
        self.assertNotIn(private,public_context)
        self.assertIn(public,public_context)
    def test_context_json_escape_expansion_stays_under_provider_input_cap(self):
        for suffix in 'abcde':self.s.remember('\x01'*1999+suffix,visibility='public')
        job=self.enqueue('draft','Write a short public response')
        context=self.s.context(job)
        serialized=json.dumps(context,ensure_ascii=False).encode('utf-8')
        self.assertLessEqual(len(serialized),43000)
        self.assertEqual(context['request'],'Write a short public response')
        self.assertLess(len(context['saved_lessons']),5)
    def test_context_fails_clearly_when_request_alone_exceeds_encoded_budget(self):
        job=self.enqueue('draft','\x01'*8000)
        with self.assertRaisesRegex(RuntimeError,'too large for Nova’s context'):
            self.s.context(job)
    def test_remember_is_private_by_default_exactly_deduplicated_and_byte_bounded(self):
        private=self.s.remember(' Keep this principle ')
        same=self.s.remember('Keep this principle')
        public=self.s.remember('Keep this principle',visibility='public')
        self.assertEqual(private['id'],same['id'])
        self.assertNotEqual(private['id'],public['id'])
        self.assertEqual(private['visibility'],'private')
        self.assertEqual(self.s.db.execute('SELECT COUNT(*) FROM lessons').fetchone()[0],2)
        self.assertEqual(self.s.remember('é'*1000)['visibility'],'private')  # 2,000 UTF-8 bytes
        with self.assertRaisesRegex(ValueError,'2,000 UTF-8 bytes'):
            self.s.remember('é'*1001)
        with self.assertRaises(ValueError):self.s.remember('\ud800')
    def test_recall_is_bounded_search_and_reaches_older_saved_lessons(self):
        for i in range(105):self.s.remember(f'archive lesson {i:03d}')
        latest=self.s.recall()
        self.assertEqual(len(latest),100)
        self.assertNotIn('archive lesson 000',[r['text'] for r in latest])
        self.assertEqual(self.s.recall('ARCHIVE LESSON 000')[0]['text'],'archive lesson 000')
        self.assertEqual(set(latest[0]),{'text','visibility','created'})
        self.s.remember("literal % and _; ' OR 1=1 --")
        self.assertEqual([r['text'] for r in self.s.recall("' OR 1=1 --")],["literal % and _; ' OR 1=1 --"])
        self.assertEqual([r['text'] for r in self.s.recall('%')],["literal % and _; ' OR 1=1 --"])
        self.assertEqual(self.s.recall('é'*100),[])  # exactly 200 UTF-8 bytes is accepted
        with self.assertRaisesRegex(ValueError,'200 UTF-8 bytes'):self.s.recall('é'*101)
        with self.assertRaises(ValueError):self.s.recall(None)
        self.assertEqual(len(self.s.snapshot()['lessons']),100)
    def test_pause_cancels_queued_and_running_only_finalizes_after_exit(self):
        a=self.enqueue('chat');self.s.claim();b=self.enqueue('draft');self.s.pause(True)
        snap={j['id']:j for j in self.s.snapshot()['jobs']}
        self.assertEqual(snap[a['id']]['status'],'cancel_requested');self.assertEqual(snap[b['id']]['status'],'cancelled')
        self.s.finish(a['id'],'completed','late result')
        self.assertEqual(self.s.snapshot()['jobs'][1]['status'],'cancelled')
        self.assertEqual(len(self.s.snapshot()['messages']),1)
    def test_restart_does_not_replay_running_call(self):
        self.enqueue('chat');self.s.claim();other=Store(self.s.root,self.s.collection)
        self.assertEqual(other.snapshot()['jobs'][0]['status'],'interrupted');self.assertIsNone(other.claim());other.db.close()
    def test_public_export_refuses_chat_and_uses_unique_file(self):
        chat=self.enqueue('chat');self.s.claim();self.s.finish(chat['id'],'completed','private')
        with self.assertRaises(ValueError):self.s.export(chat['id'])
        draft=self.enqueue('draft');self.s.claim();self.s.finish(draft['id'],'completed','poem')
        a=self.s.export(draft['id']);b=self.s.export(draft['id']);self.assertEqual(a['id'],b['id']);self.assertTrue(Path(a['path']).exists())
        self.assertTrue(Path(a['metadata_path']).exists())
        self.assertEqual(json.loads(Path(a['metadata_path']).read_text())['visibility'],'public')
    def test_collection_sidecars_are_unique_routed_and_retry_safe(self):
        cases={'article':'Articles','image':'Images','video':'Videos'}
        for kind,folder in cases.items():
            key=str(uuid.uuid4())
            first=self.s.add_collection('Reference '+kind,kind,'https://example.org/'+kind,'note',request_id=key)
            again=self.s.add_collection('Reference '+kind,kind,'https://example.org/'+kind,'note',request_id=key)
            self.assertEqual(first['id'],again['id'])
            sidecar=Path(first['metadata_path'])
            self.assertEqual(sidecar.parent.name,folder)
            self.assertTrue(sidecar.is_file())
            self.assertEqual(sidecar.stat().st_mode & 0o777,0o600)
            self.assertEqual(json.loads(sidecar.read_text())['visibility'],'private')
            with self.assertRaises(ValueError):self.s.add_collection('Changed',kind,'https://example.org/'+kind,'note',request_id=key)
        self.assertEqual(self.s.db.execute('SELECT COUNT(*) FROM collection').fetchone()[0],3)
    def test_collection_retry_recovers_sidecar_written_before_process_crash(self):
        key=uuid.uuid4().hex;folder=self.s.collection/'Articles';folder.mkdir(parents=True)
        sidecar=folder/(key+'.json');ident=uuid.uuid4().hex
        rec={'id':ident,'title':'Interrupted save','kind':'article','url':'https://example.org/source',
             'note':'source note','visibility':'private','path':'','created':time.time(),
             'metadata_path':str(sidecar),'request_id':key}
        sidecar.write_text(json.dumps(rec))
        saved=self.s.add_collection('Interrupted save','article','https://example.org/source','source note',request_id=key)
        self.assertEqual(saved['id'],ident)
        self.assertEqual(self.s.db.execute('SELECT COUNT(*) FROM collection').fetchone()[0],1)
        self.assertEqual(json.loads(sidecar.read_text())['request_id'],key)
    def test_export_recovers_matching_file_after_interrupted_metadata_save(self):
        draft=self.enqueue('draft');self.s.claim();self.s.finish(draft['id'],'completed','poem')
        target=self.s.collection/'Creations'/(draft['id']+'.txt')
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_text('Nova Satori — AI-authored original draft\nNot published. Review rights and claims before sharing.\n\npoem')
        sidecar=target.parent/(draft['id']+'.json')
        orphan={'id':uuid.uuid4().hex,'title':draft['prompt'][:100],'kind':'creation','url':'',
                'note':'AI-authored original draft. Not published.','visibility':'public','path':str(target),
                'created':time.time(),'metadata_path':str(sidecar),'request_id':draft['id']}
        sidecar.write_text(json.dumps(orphan))
        record=self.s.export(draft['id'])
        self.assertEqual(record['id'],orphan['id'])
        self.assertEqual(Path(record['path']).read_text(),target.read_text())
        self.assertTrue(Path(record['metadata_path']).is_file())
    def test_downstream_unknown_submission_not_repeated(self):
        studio=Studio(self.s)
        with patch('nova.adapters.fetch',side_effect=TimeoutError),patch.object(studio,'_headers',return_value={}):
            with self.assertRaises(RuntimeError):studio.once('test-id','/api/music/project',{'name':'Nova'})
        with patch('nova.adapters.fetch') as fetch:
            with self.assertRaises(RuntimeError):studio.once('test-id','/api/music/project',{'name':'Nova'})
            fetch.assert_not_called()
    def test_reddit_gate_has_no_network(self):
        with patch('nova.adapters.fetch') as fetch:
            with self.assertRaises(ValueError):Reddit(Path(self.tmp.name)).publish('test')
            fetch.assert_not_called()
    def test_context_remains_bounded(self):
        for _ in range(5):self.enqueue('chat','x'*11000)
        j=self.enqueue('chat','current');self.assertLess(len(json.dumps(self.s.context(j))),30000)

class HTTPTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();root=Path(self.tmp.name)
        self.app=App(root/'state',root/'config',root/'Collection',provider=FakeProvider());self.server=Server(self.app,0)
        self.app.worker.start();self.thread=threading.Thread(target=self.server.serve_forever,daemon=True);self.thread.start()
        self.base='http://127.0.0.1:'+str(self.server.server_port)
    def tearDown(self):self.server.shutdown();self.app.worker.close();self.server.server_close();self.app.store.db.close();self.tmp.cleanup()
    def req(self,path,body=None,auth=True,extra=None):
        h={'Content-Type':'application/json','X-Nova-Client':'1'}
        if auth:h['Authorization']='Bearer '+self.app.token
        h.update(extra or {})
        req=Request(self.base+path,headers=h,data=None if body is None else json.dumps(body).encode())
        try:
            with urlopen(req,timeout=3) as r:return r.status,json.load(r)
        except HTTPError as e:return e.code,json.load(e)
    def test_auth_host_and_origin_boundaries(self):
        self.assertEqual(self.req('/api/state',auth=False)[0],401)
        self.assertEqual(self.req('/api/state',extra={'Host':'evil.example'})[0],403)
        self.assertEqual(self.req('/api/pause',{'paused':True},extra={'Origin':'https://evil.example'})[0],403)
        self.assertEqual(self.req('/api/pause',{'paused':True},extra={'Sec-Fetch-Site':'cross-site'})[0],403)
        self.assertEqual(self.req('/api/pause',{'paused':True},extra={'X-Nova-Client':'0'})[0],403)
    def test_end_to_end_chat_job_and_persistence(self):
        code,job=self.req('/api/jobs',{'kind':'chat','text':'hello','request_id':str(uuid.uuid4())});self.assertEqual(code,202)
        for _ in range(30):
            _,state=self.req('/api/job/'+job['id'])
            if state['status']=='completed':break
            time.sleep(.05)
        self.assertEqual(state['result'],'Fixture response: hello')
        _,snap=self.req('/api/state');self.assertEqual(snap['messages'][-1]['role'],'assistant')
    def test_session_cookie_and_invalid_inputs(self):
        self.assertEqual(self.req('/session',{'token':'wrong'},auth=False)[0],401)
        self.assertEqual(self.req('/session',{'token':self.app.token},auth=False)[0],200)
        self.assertEqual(self.req('/api/jobs',{'kind':'shell','text':'ls','request_id':str(uuid.uuid4())})[0],400)
        self.assertEqual(self.req('/api/collection',{'title':'X','kind':'article','url':'file:///etc/passwd'})[0],400)
        self.assertEqual(self.req('/api/reddit/publish',{})[0],409)
    def test_memory_recall_is_authenticated_and_searches_saved_lessons(self):
        self.app.store.remember('Private memory recall sentinel')
        self.app.store.remember('Public memory recall sentinel',visibility='public')
        self.assertEqual(self.req('/api/memory?q=recall',auth=False)[0],401)
        code,result=self.req('/api/memory?q=recall')
        self.assertEqual(code,200)
        self.assertEqual({(r['text'],r['visibility']) for r in result['lessons']},
                         {('Private memory recall sentinel','private'),('Public memory recall sentinel','public')})
    def test_collection_request_id_is_idempotent_over_http(self):
        key=str(uuid.uuid4())
        body={'title':'Reference','kind':'article','url':'https://example.org/reference','note':'Useful','visibility':'private','request_id':key}
        code,first=self.req('/api/collection',body)
        self.assertEqual(code,201)
        code,again=self.req('/api/collection',body)
        self.assertEqual(code,201)
        self.assertEqual(first['id'],again['id'])
        self.assertTrue(Path(first['metadata_path']).is_file())
        self.assertEqual(first['request_id'],key.replace('-',''))
        self.assertEqual(self.app.store.db.execute('SELECT COUNT(*) FROM collection').fetchone()[0],1)
    def test_fixture_provider_does_not_run_on_state_poll(self):
        with patch.object(self.app.provider,'run') as run:
            for _ in range(3):self.req('/api/state')
            run.assert_not_called()

class MCPTests(unittest.TestCase):
    def test_bookmark_forwards_stable_request_id(self):
        key=str(uuid.uuid4())
        with patch('nova.mcp.request',return_value={'id':'saved'}) as request:
            result=mcp.call('nova_save_bookmark',{'title':'Reference','url':'https://example.org','kind':'article','note':'Useful','request_id':key})
        self.assertEqual(result,{'id':'saved'})
        request.assert_called_once_with('/api/collection',{'title':'Reference','url':'https://example.org','kind':'article','note':'Useful','visibility':'private','request_id':key})

    def test_recall_tool_is_explicit_and_searches_only_when_called(self):
        tool=next(t for t in mcp.TOOLS if t['name']=='nova_recall')
        self.assertIn('only when the human requests',tool['description'])
        self.assertEqual(tool['inputSchema']['required'],['query'])
        with patch('nova.mcp.request',return_value={'lessons':[]}) as request:
            self.assertEqual(mcp.call('nova_recall',{'query':'needle'}),{'lessons':[]})
        request.assert_called_once_with('/api/memory?q=needle')

    def test_stdio_discards_oversized_line_without_unbounded_read(self):
        payload=(b'x'*70000)+b'\n'+json.dumps({'jsonrpc':'2.0','id':1,'method':'ping'}).encode()+b'\n'
        stdin=io.TextIOWrapper(io.BytesIO(payload),encoding='utf-8');stdout=io.StringIO()
        with patch.object(sys,'stdin',stdin),patch.object(sys,'stdout',stdout):mcp.main()
        replies=[json.loads(line) for line in stdout.getvalue().splitlines()]
        self.assertEqual(replies,[{'jsonrpc':'2.0','id':1,'result':{}}])

if __name__=='__main__':unittest.main()

class ScheduleTests(unittest.TestCase):
    def test_paused_schedule_waits_then_uses_only_public_context(self):
        from nova.worker import Worker
        class RecordingProvider(FakeProvider):
            seen=[]
            def run(self,persona,context,cancel):
                self.seen.append(context)
                return 'A public original poem.'
        with tempfile.TemporaryDirectory() as t:
            root=Path(t);store=Store(root/'state',root/'Collection')
            private=store.enqueue('chat','SCHEDULE_PRIVATE_SENTINEL',str(uuid.uuid4()));store.cancel(private['id'])
            store.remember('SCHEDULE_PRIVATE_SENTINEL')
            store.set('next_draft',0);store.pause(True)
            provider=RecordingProvider();worker=Worker(store,provider);worker.start()
            try:
                time.sleep(.15);self.assertEqual(provider.seen,[])
                store.pause(False);worker.wake.set()
                end=time.monotonic()+3
                while not provider.seen and time.monotonic()<end:time.sleep(.03)
                self.assertEqual(len(provider.seen),1)
                self.assertNotIn('SCHEDULE_PRIVATE_SENTINEL',json.dumps(provider.seen))
                self.assertEqual(provider.seen[0]['visibility'],'public')
                self.assertEqual(store.snapshot()['jobs'][0]['origin'],'schedule')
            finally:worker.close();store.db.close()

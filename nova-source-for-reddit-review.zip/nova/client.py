from __future__ import annotations
import argparse
import json
import sys
import time
import uuid
import webbrowser
from pathlib import Path
from urllib.parse import quote
from urllib.request import Request,build_opener,ProxyHandler
from urllib.error import HTTPError

BASE='http://127.0.0.1:8791'
CONFIG=Path.home()/'.config/nova-satori'

def request(path, body=None):
    token=(CONFIG/'token').read_text().strip()
    headers={'Authorization':'Bearer '+token,'X-Nova-Client':'1','Content-Type':'application/json'}
    data=None if body is None else json.dumps(body).encode()
    req=Request(BASE+path,data=data,headers=headers)
    try:
        with build_opener(ProxyHandler({})).open(req,timeout=30) as r:return json.load(r)
    except HTTPError as e:
        try:message=json.load(e).get('error','Nova request failed.')
        except Exception:message='Nova request failed.'
        raise RuntimeError(message) from None

def main():
    p=argparse.ArgumentParser(description='Nova private chat and creative workspace')
    sub=p.add_subparsers(dest='action',required=True)
    sub.add_parser('open');sub.add_parser('status');sub.add_parser('pause');sub.add_parser('resume')
    for name in ['chat','draft','music_brief','image_brief']:
        x=sub.add_parser(name);x.add_argument('text',nargs='?');x.add_argument('--wait',action='store_true');x.add_argument('--request-id',default=None)
    x=sub.add_parser('job');x.add_argument('id')
    x=sub.add_parser('cancel');x.add_argument('id')
    x=sub.add_parser('export');x.add_argument('id')
    x=sub.add_parser('memories');x.add_argument('query',nargs='?',default='')
    x=sub.add_parser('remember');x.add_argument('text',nargs='?');x.add_argument('--public',action='store_true')
    x=sub.add_parser('bookmark');x.add_argument('title');x.add_argument('url');x.add_argument('--kind',default='article');x.add_argument('--note',default='');x.add_argument('--public',action='store_true')
    a=p.parse_args()
    try:
        if a.action=='open':
            token=(CONFIG/'token').read_text().strip()
            webbrowser.open(BASE+'/#token='+token)
            print('Opened Nova’s private workspace.');return
        if a.action=='status':
            out=request('/api/state');out={k:v for k,v in out.items() if k not in {'messages','collection','jobs','lessons'}}
        elif a.action in {'pause','resume'}:out=request('/api/pause',{'paused':a.action=='pause'})
        elif a.action=='job':out=request('/api/job/'+a.id)
        elif a.action in {'cancel','export'}:out=request('/api/'+a.action,{'id':a.id})
        elif a.action=='memories':out=request('/api/memory?q='+quote(a.query))
        elif a.action=='remember':out=request('/api/memory',{'text':a.text or sys.stdin.read(),'visibility':'public' if a.public else 'private'})
        elif a.action=='bookmark':out=request('/api/collection',{'title':a.title,'url':a.url,'kind':a.kind,'note':a.note,'visibility':'public' if a.public else 'private'})
        else:
            text=a.text if a.text is not None else sys.stdin.read()
            out=request('/api/jobs',{'kind':a.action,'text':text,'request_id':a.request_id or str(uuid.uuid4())})
            if a.wait:
                end=time.monotonic()+210
                while out['status'] in {'queued','running','cancel_requested'} and time.monotonic()<end:
                    time.sleep(.5);out=request('/api/job/'+out['id'])
        print(json.dumps(out,ensure_ascii=False,indent=2))
    except (OSError,RuntimeError) as exc:
        print(str(exc),file=sys.stderr);raise SystemExit(1)
if __name__=='__main__':main()

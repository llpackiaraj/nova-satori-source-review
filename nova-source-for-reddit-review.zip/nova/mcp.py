"""Narrow stdio MCP bridge. No arbitrary URLs, shell, publishing or history enumeration."""
from __future__ import annotations
import json
import sys
import uuid
from urllib.parse import quote
from .client import request

TOOLS=[
 {'name':'nova_recall','description':'Search Nova saved lessons only when the human requests recall. Returns private notes to this authorized chat; never use them for public drafts.','inputSchema':{'type':'object','properties':{'query':{'type':'string'}},'required':['query'],'additionalProperties':False}},
 {'name':'nova_remember','description':'Save an explicitly authorized lasting lesson in Nova private memory. Never grants new permissions; private notes never enter public drafting.','inputSchema':{'type':'object','properties':{'text':{'type':'string'}},'required':['text'],'additionalProperties':False}},
 {'name':'nova_status','description':'Read Nova availability and integration blockers; excludes private conversation history.','inputSchema':{'type':'object','properties':{},'additionalProperties':False}},
 {'name':'nova_chat','description':'Send an explicitly user-authorized private message to Nova. Saves it in Nova private chat; returns a job ID. Do not send unrelated private data.','inputSchema':{'type':'object','properties':{'text':{'type':'string'},'request_id':{'type':'string'}},'required':['text'],'additionalProperties':False}},
 {'name':'nova_job','description':'Read the result of a previously submitted Nova job by its ID.','inputSchema':{'type':'object','properties':{'id':{'type':'string'}},'required':['id'],'additionalProperties':False}},
 {'name':'nova_create','description':'Prepare an explicitly requested public draft, image brief, or music brief. Public context only; never publishes or renders.','inputSchema':{'type':'object','properties':{'kind':{'type':'string','enum':['draft','music_brief','image_brief']},'text':{'type':'string'},'request_id':{'type':'string'}},'required':['kind','text'],'additionalProperties':False}},
 {'name':'nova_save_bookmark','description':'Save a user-authorized article/image/video source link to Nova collection; does not fetch it. Private by default.','inputSchema':{'type':'object','properties':{'title':{'type':'string'},'url':{'type':'string'},'kind':{'type':'string','enum':['article','image','video']},'note':{'type':'string'},'request_id':{'type':'string'}},'required':['title','url','kind','request_id'],'additionalProperties':False}}
]

def call(name,args):
    if name=='nova_recall':return request('/api/memory?q='+quote(args['query']))
    if name=='nova_remember':return request('/api/memory',{'text':args['text'],'visibility':'private'})
    if name=='nova_status':
        v=request('/api/state');return {k:v[k] for k in ['paused','model','worker','provider','limits','integrations']}
    if name=='nova_chat':return request('/api/jobs',{'kind':'chat','text':args['text'],'request_id':args.get('request_id') or str(uuid.uuid4())})
    if name=='nova_create':
        if args.get('kind') not in {'draft','music_brief','image_brief'}:raise ValueError('Invalid creation kind.')
        return request('/api/jobs',{'kind':args['kind'],'text':args['text'],'request_id':args.get('request_id') or str(uuid.uuid4())})
    if name=='nova_job':
        if not isinstance(args.get('id'),str) or len(args['id'])!=32 or not all(c in '0123456789abcdef' for c in args['id']):raise ValueError('Invalid job ID.')
        return request('/api/job/'+args['id'])
    if name=='nova_save_bookmark':
        return request('/api/collection',{'title':args['title'],'url':args['url'],'kind':args['kind'],'note':args.get('note',''),'visibility':'private','request_id':args['request_id']})
    raise ValueError('Unknown tool.')

def main():
    while True:
        raw=sys.stdin.buffer.readline(65537)
        if not raw:break
        if len(raw)>65536:
            while raw and not raw.endswith(b'\n'):raw=sys.stdin.buffer.readline(65537)
            continue
        try:
            data=json.loads(raw);method=data.get('method');ident=data.get('id')
            if ident is None:continue
            if method=='initialize':result={'protocolVersion':'2024-11-05','capabilities':{'tools':{}},'serverInfo':{'name':'nova-satori','version':'0.1.0'}}
            elif method=='ping':result={}
            elif method=='tools/list':result={'tools':TOOLS}
            elif method=='tools/call':
                try:
                    params=data.get('params',{});value=call(params.get('name'),params.get('arguments',{}))
                    result={'content':[{'type':'text','text':json.dumps(value,ensure_ascii=False)}]}
                except (ValueError,KeyError,OSError,RuntimeError):result={'isError':True,'content':[{'type':'text','text':'Nova request failed. Check Nova status or open its local workspace.'}]}
            else:
                print(json.dumps({'jsonrpc':'2.0','id':ident,'error':{'code':-32601,'message':'Method not found'}}),flush=True);continue
            print(json.dumps({'jsonrpc':'2.0','id':ident,'result':result}),flush=True)
        except (ValueError,TypeError,AttributeError):continue
if __name__=='__main__':main()

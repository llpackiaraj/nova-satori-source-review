"""Explicit external capabilities. No model-directed URLs or automatic retries."""
from __future__ import annotations
import json
import re
import time
from pathlib import Path
from urllib.request import Request,build_opener,ProxyHandler,HTTPRedirectHandler
from urllib.error import HTTPError,URLError

class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self,*_):raise RuntimeError('Unexpected redirect refused.')
OPENER=build_opener(ProxyHandler({}),NoRedirect())

def fetch(url,headers=None,body=None,timeout=15):
    req=Request(url,data=None if body is None else json.dumps(body).encode(),headers={'Content-Type':'application/json',**(headers or {})})
    with OPENER.open(req,timeout=timeout) as r:
        data=r.read(2*1024*1024+1)
        if len(data)>2*1024*1024:raise RuntimeError('Adapter response too large.')
        return data

class Studio:
    base='http://127.0.0.1:8876'
    def __init__(self,store):self.store=store;self.last={'state':'not_checked','reason':'Check Studio readiness before preparing a generation.'};self.checked=0
    def _headers(self):
        source=fetch(self.base+'/').decode()
        m=re.search(r'<meta name="studio-token" content="([A-Za-z0-9_-]{20,100})"',source)
        if not m:raise RuntimeError('Studio browser authentication unavailable.')
        return {'X-Studio-Token':m.group(1),'X-Studio-Trusted-Client':'local'}
    def status(self):
        if time.monotonic()-self.checked<60:return self.last
        self.checked=time.monotonic()
        try:
            raw=json.loads(fetch(self.base+'/api/music/status',self._headers()))
            self.last={'state':'ready' if raw.get('generation_available') else 'blocked','reason':raw.get('generation_reason') or 'Local YuE2 available. Explicit submit required.',
                       'generation_available':bool(raw.get('generation_available')),'observed_at':time.time()}
        except (OSError,ValueError,RuntimeError):self.last={'state':'blocked','reason':'Studio X readiness unavailable. Open Studio X and check its Music page.','observed_at':time.time()}
        return self.last
    def once(self,ident,path,payload):
        # Intent commits before network. Unknown response is never resent.
        with self.store.lock,self.store.db:
            row=self.store.db.execute('SELECT * FROM submissions WHERE id=?',(ident,)).fetchone()
            if row:
                if row['payload']!=json.dumps(payload,sort_keys=True):raise ValueError('Submission ID belongs to different content.')
                if row['state']=='confirmed':return json.loads(row['receipt'])
                raise RuntimeError('Submission outcome uncertain. Reconcile in Studio X; Nova will not retry it.')
            self.store.db.execute('INSERT INTO submissions(id,adapter,state,payload,updated) VALUES (?,?,?,?,?)',(ident,'studio','submitting',json.dumps(payload,sort_keys=True),time.time()))
        try:
            receipt=json.loads(fetch(self.base+path,self._headers(),payload,timeout=25))
            with self.store.lock,self.store.db:self.store.db.execute("UPDATE submissions SET state='confirmed',receipt=?,updated=? WHERE id=?",(json.dumps(receipt),time.time(),ident))
            return receipt
        except Exception:
            with self.store.lock,self.store.db:self.store.db.execute("UPDATE submissions SET state='unknown',updated=? WHERE id=?",(time.time(),ident))
            raise RuntimeError('Studio submission response was uncertain. Inspect Studio project state before any resubmit.') from None
    def music(self,request_id,style,lyrics,run=False):
        import uuid
        try:uuid.UUID(request_id)
        except (ValueError,TypeError,AttributeError):raise ValueError('Valid request ID required.')
        if not isinstance(run,bool) or not isinstance(style,str) or not style.strip() or len(style)>8000 or not isinstance(lyrics,str) or not lyrics.strip() or len(lyrics)>12000:raise ValueError('Style and lyrics required within the displayed limits.')
        if self.store.setting('paused'):raise ValueError('Nova is paused.')
        if run and not self.status().get('generation_available'):raise ValueError('Studio music generation unavailable: '+self.last['reason'])
        # Each project is Nova-owned. No pre-existing project or global settings are changed.
        rec=self.once(request_id+'-project','/api/music/project',{'name':'Nova Satori '+request_id[:8]})
        project=rec.get('id')
        if not isinstance(project,str):raise RuntimeError('Studio project receipt did not include an ID.')
        return self.once(request_id+'-generation','/api/music/generation',{'project_id':project,'style':style,'lyrics':lyrics,'run':run})

class Reddit:
    """No browser-cookie extraction. Approved OAuth connection is an explicit future gate."""
    def __init__(self,config):self.config=Path(config)/'reddit.json'
    def status(self):
        # Do not infer platform approval from a logged-in browser or a boolean.
        return {'state':'blocked','reason':'Approved app registration, access scope and OAuth connection have not been verified. No unattended Reddit network actions are enabled.'}
    def publish(self,*_,**__):raise ValueError(self.status()['reason'])

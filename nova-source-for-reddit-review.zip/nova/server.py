from __future__ import annotations
import argparse
import fcntl
import hmac
import json
import os
import secrets
import signal
import threading
import time
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler,ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit,parse_qs
from .store import Store
from .provider import CodexProvider
from .worker import Worker
from .adapters import Studio,Reddit

ROOT=Path(__file__).resolve().parent.parent
DEFAULT_STATE=Path.home()/'.local/state/nova-satori'
DEFAULT_CONFIG=Path.home()/'.config/nova-satori'
DEFAULT_COLLECTION=Path('/srv/nova-satori/Collection')

class App:
    def __init__(self,state=DEFAULT_STATE,config=DEFAULT_CONFIG,collection=DEFAULT_COLLECTION,model=None,provider=None):
        self.config=Path(config);self.config.mkdir(mode=0o700,parents=True,exist_ok=True);self.config.chmod(0o700)
        token_file=self.config/'token'
        if not token_file.exists():
            with token_file.open('x') as f:f.write(secrets.token_urlsafe(32))
            token_file.chmod(0o600)
        self.token=token_file.read_text().strip()
        if len(self.token)<32:raise ValueError('Invalid local Nova token.')
        self.store=Store(Path(state),Path(collection));self.provider=provider or CodexProvider(Path(state)/'runs',model)
        self.worker=Worker(self.store,self.provider);self.started=time.time()
        self.studio=Studio(self.store);self.reddit=Reddit(self.config)
    def state(self):
        value=self.store.snapshot()
        value.update({'model':self.provider.model or self.provider.last.get('model') or 'Codex subscription default (model not reported)','provider':self.provider.last,
            'worker':{'state':'paused' if value['paused'] else ('running' if self.worker.active else 'ready'), 'active_job':self.worker.active,'available_since':self.started,'last_heartbeat':self.worker.last_heartbeat},
            'limits':{'private_chats_per_day':60,'public_creations_per_day':4,'background_every_hours':6,'provider_timeout_seconds':180},
            'integrations':{'reddit':{'state':'blocked','reason':'API/app approval and OAuth account connection required. Drafts are not published.'},
            'pepper':{'state':'launcher','reason':'Open Nova Satori from Pepper’s Library. Native conversational routing is not installed.'},
            'studio_x':self.studio.last,
            'executive_producer':{'state':'deferred','reason':'Waiting for its supported integration contract.'},
            'main_chat':{'state':'local_bridge','reason':'Nova CLI/MCP shares this store. Existing ChatGPT transcript is not automatically synchronized.'}}})
        return value

class Server(ThreadingHTTPServer):
    daemon_threads=True
    allow_reuse_address=True
    def __init__(self,app,port=8791):
        self.app=app;super().__init__(('127.0.0.1',port),Handler)

class Handler(BaseHTTPRequestHandler):
    server_version='Nova/0.1'
    def log_message(self,*args):pass  # Never log tokens, prompts, URLs or private content.
    def send(self,code,data,typ='application/json',cookie=None):
        raw=json.dumps(data,ensure_ascii=False).encode() if typ=='application/json' else data
        self.send_response(code);self.send_header('Content-Type',typ);self.send_header('Content-Length',str(len(raw)))
        self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.send_header('Referrer-Policy','no-referrer')
        self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
        if cookie:self.send_header('Set-Cookie',cookie)
        self.end_headers()
        try:self.wfile.write(raw)
        except (BrokenPipeError,ConnectionResetError):pass
    def host_ok(self):
        return self.headers.get('Host') in {f'127.0.0.1:{self.server.server_port}',f'localhost:{self.server.server_port}'}
    def authorized(self):
        token=self.headers.get('Authorization','').removeprefix('Bearer ')
        if not token:
            try:
                c=SimpleCookie();c.load(self.headers.get('Cookie',''));token=c['nova_session'].value if 'nova_session' in c else ''
            except Exception:return False
        return hmac.compare_digest(token,self.server.app.token)
    def body(self):
        if self.headers.get('Content-Type','').split(';')[0]!='application/json':raise ValueError('JSON required.')
        try:n=int(self.headers.get('Content-Length','0'))
        except ValueError:raise ValueError('Invalid request length.')
        if not 0<n<=65536:raise ValueError('Request must be under 64 KiB.')
        value=json.loads(self.rfile.read(n))
        if not isinstance(value,dict):raise ValueError('Expected a JSON object.')
        return value
    def do_GET(self):
        if not self.host_ok():return self.send(403,{'error':'Invalid local host.'})
        path=urlsplit(self.path).path
        if path=='/health':return self.send(200,{'service':'nova-satori','status':'online','version':'0.1.0'})
        if path=='/api/memory':
            if not self.authorized():return self.send(401,{'error':'Local sign-in required.'})
            try:return self.send(200,{'lessons':self.server.app.store.recall(parse_qs(urlsplit(self.path).query).get('q',[''])[0])})
            except ValueError as exc:return self.send(400,{'error':str(exc)})
        if path.startswith('/api/job/'):
            if not self.authorized():return self.send(401,{'error':'Local sign-in required.'})
            job_id=path.removeprefix('/api/job/')
            with self.server.app.store.lock:
                row=self.server.app.store.db.execute('SELECT * FROM jobs WHERE id=?',(job_id,)).fetchone()
            return self.send(200,dict(row)) if row else self.send(404,{'error':'Request not found.'})
        if path=='/api/state':
            if not self.authorized():return self.send(401,{'error':'Open Nova with the desktop launcher to sign in.'})
            return self.send(200,self.server.app.state())
        files={'/':'index.html','/app.js':'app.js','/app.css':'app.css','/static/app.js':'app.js','/static/app.css':'app.css'}
        if path not in files:return self.send(404,{'error':'Not found.'})
        p=Path(__file__).parent/'static'/files[path]
        typ='text/html; charset=utf-8' if path=='/' else ('application/javascript' if path.endswith('.js') else 'text/css')
        return self.send(200,p.read_bytes(),typ)
    def do_POST(self):
        if not self.host_ok():return self.send(403,{'error':'Invalid local host.'})
        origin=self.headers.get('Origin','')
        if origin and origin!=f'http://{self.headers.get("Host")}':return self.send(403,{'error':'Same-origin request required.'})
        if self.headers.get('Sec-Fetch-Site','') not in {'','same-origin','none'}:return self.send(403,{'error':'Cross-site request rejected.'})
        if self.headers.get('X-Nova-Client')!='1':return self.send(403,{'error':'Nova client header required.'})
        path=urlsplit(self.path).path
        if path!='/session' and not self.authorized():return self.send(401,{'error':'Local sign-in required.'})
        try:
            b=self.body(); app=self.server.app
            if path=='/session':
                if not isinstance(b.get('token'),str) or not hmac.compare_digest(b['token'],app.token):return self.send(401,{'error':'Invalid Nova token. Open Nova through its launcher.'})
                return self.send(200,{'ok':True},cookie=f'nova_session={app.token}; HttpOnly; SameSite=Strict; Path=/')
            if path=='/api/studio/status':return self.send(200,app.studio.status())
            if path=='/api/studio/music':return self.send(202,app.studio.music(b.get('request_id'),b.get('style'),b.get('lyrics'),b.get('run',False)))
            if path=='/api/reddit/publish':return self.send(409,app.reddit.status())
            if path=='/api/memory':return self.send(201,app.store.remember(b.get('text'),b.get('visibility','private')))
            if path=='/api/jobs':
                result=app.store.enqueue(b.get('kind'),b.get('text'),b.get('request_id'));app.worker.wake.set()
                return self.send(202,result)
            if path=='/api/pause':app.store.pause(b.get('paused'));app.worker.wake.set();return self.send(200,{'paused':app.store.setting('paused')})
            if path=='/api/cancel':app.store.cancel(b.get('id'));return self.send(200,{'ok':True})
            if path=='/api/collection':return self.send(201,app.store.add_collection(b.get('title'),b.get('kind'),b.get('url',''),b.get('note',''),b.get('visibility','private'),request_id=b.get('request_id')))
            if path=='/api/export':return self.send(201,app.store.export(b.get('id')))
            return self.send(404,{'error':'Not found.'})
        except (ValueError,TypeError) as exc:return self.send(400,{'error':str(exc)[:300]})
        except OSError:return self.send(503,{'error':'Storage unavailable. Work is retained; check the media mount.'})

def main():
    p=argparse.ArgumentParser();p.add_argument('--port',type=int,default=8791);p.add_argument('--state',type=Path,default=DEFAULT_STATE);p.add_argument('--config',type=Path,default=DEFAULT_CONFIG);p.add_argument('--collection',type=Path,default=DEFAULT_COLLECTION);p.add_argument('--model',default=None);a=p.parse_args()
    os.umask(0o077)
    a.state.mkdir(mode=0o700,parents=True,exist_ok=True)
    ownership=(a.state/'service.lock').open('a')
    try:fcntl.flock(ownership,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:raise SystemExit('Nova is already running for this state directory.')
    app=App(a.state,a.config,a.collection,a.model);server=Server(app,a.port);app.worker.start()
    def stop(*_):
        app.worker.stop_event.set()
        if app.worker.active:app.store.cancel(app.worker.active)
        threading.Thread(target=server.shutdown,daemon=True).start()
    signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
    try:server.serve_forever(poll_interval=.3)
    finally:app.worker.close();server.server_close()
if __name__=='__main__':main()

(() => {
  "use strict";

  const $ = (id) => document.getElementById(id);
  const loginView = $("loginView");
  const appView = $("appView");
  const loginForm = $("loginForm");
  const loginMessage = $("loginMessage");
  const tokenInput = $("tokenInput");
  const messages = $("messages");
  const emptyChat = $("emptyChat");
  const chatForm = $("chatForm");
  const chatInput = $("chatInput");
  const chatSubmit = $("chatSubmit");
  const publicForm = $("publicForm");
  const publicInput = $("publicInput");
  const collectionForm = $("collectionForm");
  const pauseButton = $("pauseButton");
  const connectionState = $("connectionState");
  const globalNotice = $("globalNotice");

  let currentState = null;
  let renderedMessagesKey = null;
  let renderedJobsKey = null;
  let renderedCollectionKey = null;
  let pollTimer = null;
  let pollInFlight = false;
  let pollAgain = false;
  let noticeTimer = null;
  let actionInFlight = false;
  let collectionInFlight = false;
  let collectionPending = null;
  try { collectionPending = JSON.parse(sessionStorage.getItem("nova.pendingCollection") || "null"); } catch (_) {}
  let pendingRequest = { chat: null, public: null };
  let pauseInFlight = false;
  const canceling = new Set();
  const exporting = new Set();

  class ApiError extends Error {
    constructor(status, message) {
      super(message || `Nova returned ${status}.`);
      this.status = status;
    }
  }

  async function request(path, options = {}) {
    const headers = { "X-Nova-Client": "1", Accept: "application/json", ...(options.headers || {}) };
    const init = {
      method: options.method || "GET",
      credentials: "same-origin",
      cache: "no-store",
      headers,
    };
    if (options.body !== undefined) {
      headers["Content-Type"] = "application/json";
      init.body = JSON.stringify(options.body);
    }
    let response;
    try {
      response = await fetch(path, init);
    } catch (_error) {
      throw new ApiError(0, "Nova could not be reached. Check that the local service is running, then try again.");
    }

    let data = null;
    const contentType = response.headers.get("content-type") || "";
    if (contentType.includes("application/json")) {
      try { data = await response.json(); } catch (_error) { data = null; }
    } else if (response.status !== 204) {
      try { data = await response.text(); } catch (_error) { data = null; }
    }
    if (!response.ok) {
      const message = data && typeof data === "object"
        ? (data.error || data.message || data.detail)
        : null;
      throw new ApiError(response.status, typeof message === "string" ? message : `Nova returned ${response.status}.`);
    }
    return data;
  }

  function setMessage(node, text = "", type = "") {
    node.textContent = text;
    node.classList.toggle("error", type === "error");
    node.classList.toggle("success", type === "success");
  }

  function showNotice(text, type = "") {
    if (noticeTimer !== null) window.clearTimeout(noticeTimer);
    noticeTimer = null;
    globalNotice.textContent = text;
    globalNotice.className = "notice-bar";
    if (type) globalNotice.classList.add(type);
    globalNotice.hidden = !text;
    if (text) {
      noticeTimer = window.setTimeout(() => {
        globalNotice.hidden = true;
        noticeTimer = null;
      }, 8000);
    }
  }

  function setConnection(text, offline = false) {
    connectionState.textContent = text;
    connectionState.classList.toggle("is-offline", offline);
  }

  function sessionExpired(error) {
    if (error && (error.status === 401 || error.status === 403)) {
      showLogin("Your local session ended. Sign in again through nova-open, then return to the same workspace.");
      return true;
    }
    return false;
  }

  function showLogin(message = "") {
    stopPolling();
    appView.hidden = true;
    loginView.hidden = false;
    if (message) setMessage(loginMessage, message, "error");
    setTimeout(() => tokenInput.focus(), 0);
  }

  function showApp() {
    loginView.hidden = true;
    appView.hidden = false;
    setMessage(loginMessage, "");
    startPolling();
  }

  function removeSensitiveUrlParts() {
    if (window.location.hash || window.location.search) {
      window.history.replaceState(null, "", window.location.pathname);
    }
  }

  function takeFragmentToken() {
    const fragment = window.location.hash;
    if (!fragment) return "";
    let token = "";
    try {
      const params = new URLSearchParams(fragment.slice(1));
      token = params.get("token") || "";
    } catch (_error) {
      token = "";
    }
    removeSensitiveUrlParts();
    return token;
  }

  async function signIn(token) {
    if (!token) return false;
    try {
      await request("/session", { method: "POST", body: { token } });
      const state = await request("/api/state");
      applyState(state);
      showApp();
      return true;
    } catch (error) {
      if (error.status === 401 || error.status === 403) {
        showLogin("That local sign-in did not work. Open Nova with nova-open for a fresh handoff, or enter the local token here.");
      } else {
        showLogin(error.message || "Nova could not sign in.");
      }
      return false;
    }
  }

  async function bootstrap() {
    const token = takeFragmentToken();
    if (token) {
      showLogin("Signing in to your local Nova workspace…");
      setMessage(loginMessage, "Signing in to your local Nova workspace…");
      const signedIn = await signIn(token);
      tokenInput.value = "";
      if (signedIn) return;
      return;
    }
    removeSensitiveUrlParts();
    try {
      const state = await request("/api/state");
      applyState(state);
      showApp();
    } catch (error) {
      showLogin(error.status === 401 || error.status === 403
        ? "Sign in through the local launcher to open your workspace."
        : error.message);
    }
  }

  function formatDate(value) {
    if (value === null || value === undefined || value === "") return "";
    let date;
    if (typeof value === "number" || /^\d+(\.\d+)?$/.test(String(value))) {
      let number = Number(value);
      if (number < 1e12) number *= 1000;
      date = new Date(number);
    } else {
      date = new Date(value);
    }
    if (Number.isNaN(date.getTime())) return String(value);
    try {
      return new Intl.DateTimeFormat(undefined, { month: "short", day: "numeric", hour: "numeric", minute: "2-digit" }).format(date);
    } catch (_error) {
      return date.toLocaleString();
    }
  }

  function timestamp(value) {
    if (value === null || value === undefined || value === "") return 0;
    const numeric = typeof value === "number" || /^\d+(\.\d+)?$/.test(String(value));
    const date = numeric ? Number(value) * (Number(value) < 1e12 ? 1000 : 1) : Date.parse(value);
    return Number.isFinite(date) ? date : 0;
  }

  function shortValue(value, fallback = "Not reported") {
    if (value === null || value === undefined || value === "") return fallback;
    if (typeof value === "string" || typeof value === "number" || typeof value === "boolean") return String(value);
    if (Array.isArray(value)) return value.map((item) => shortValue(item, "")).filter(Boolean).join(", ") || fallback;
    if (typeof value === "object") {
      for (const key of ["name", "label", "status", "state", "value", "message", "detail", "reason"]) {
        if (value[key] !== undefined && value[key] !== null && value[key] !== "") return shortValue(value[key], fallback);
      }
      try { return JSON.stringify(value); } catch (_error) { return fallback; }
    }
    return fallback;
  }

  function categoryFor(value) {
    const word = String(value || "").toLowerCase();
    if (/blocked|unavailable|failed|error|expired|disconnected|unknown|interrupted|paused|login required|not configured/.test(word)) return "warn";
    if (/ready|connected|available|enabled|healthy|done|complete|succeeded|active/.test(word)) return "ok";
    return "";
  }

  function displayName(value) {
    return String(value || "")
      .replace(/[_-]+/g, " ")
      .replace(/([a-z])([A-Z])/g, "$1 $2")
      .replace(/\b\w/g, (letter) => letter.toUpperCase());
  }

  function element(tag, className = "", text = null) {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== null && text !== undefined) node.textContent = String(text);
    return node;
  }

  function renderModel(model) {
    const chip = $("modelChip");
    chip.replaceChildren();
    const spark = element("span", "model-spark", "✳");
    spark.setAttribute("aria-hidden", "true");
    chip.append(spark, element("span", "", shortValue(model, "Model not reported")));
  }

  function renderStatus(state) {
    const paused = state.paused === true;
    const worker = state.worker;
    const workerValue = shortValue(worker, "Idle");
    const workerClass = categoryFor(workerValue);
    const rows = [
      ["Worker", workerValue, workerClass],
      ["Model", shortValue(state.model, "Not reported"), categoryFor(state.model)],
    ];
    const container = $("statusSummary");
    container.replaceChildren();
    for (const [label, value, stateClass] of rows) {
      const row = element("div", "status-row");
      row.append(element("span", "status-label", label));
      row.append(element("span", `status-value ${stateClass}`, value));
      container.append(row);
    }

    const pauseBox = pauseButton.closest(".pause-box");
    $("pauseTitle").textContent = paused ? "Nova inference is paused" : "Nova inference is active";
    $("pauseHelp").textContent = paused
      ? "Resume Nova to start new inference. Other GPU work is untouched."
      : "Pausing affects Nova's own inference only.";
    pauseBox.classList.toggle("is-paused", paused);
    pauseButton.textContent = paused ? "Resume Nova" : "Pause Nova";
    pauseButton.disabled = pauseInFlight || actionInFlight;
    pauseButton.setAttribute("aria-pressed", String(paused));

    for (const button of [chatSubmit, ...publicForm.querySelectorAll("button[type=submit]")]) {
      button.disabled = paused || actionInFlight;
      button.title = paused ? "Resume Nova inference before sending new work." : "";
    }
    chatInput.disabled = paused || actionInFlight;
    publicInput.disabled = paused || actionInFlight;

    const modelText = shortValue(state.model, "Model status not reported");
    renderModel(modelText);
    renderIntegrations(state.integrations);
    renderLimits(state.limits);
  }

  function renderIntegrations(integrations) {
    const container = $("integrationList");
    container.replaceChildren();
    let entries = [];
    if (Array.isArray(integrations)) {
      entries = integrations.map((item, index) => [shortValue(item && item.name, `Integration ${index + 1}`), item]);
    } else if (integrations && typeof integrations === "object") {
      entries = Object.entries(integrations);
    }
    if (!entries.length) {
      container.append(element("p", "muted-copy", "No integrations are configured."));
      return;
    }
    for (const [rawName, info] of entries) {
      const item = typeof info === "object" && info !== null ? info : { status: info };
      const stateText = shortValue(item.status ?? item.state ?? item.available, "Status not reported");
      const detail = item.reason || item.error || item.detail || item.message || item.summary || "";
      const next = item.next_action || item.next || item.action || "";
      const card = element("div", "integration-item");
      const top = element("div", "integration-top");
      top.append(element("span", "integration-name", displayName(rawName)));
      top.append(element("span", `integration-state ${categoryFor(stateText)}`, stateText));
      card.append(top);
      if (detail) card.append(element("p", "integration-detail", shortValue(detail, "")));
      if (next) card.append(element("p", "integration-detail", `Next: ${shortValue(next, "")}`));
      else if (categoryFor(stateText) === "warn") card.append(element("p", "integration-detail", "Next: review this gate before using the integration."));
      container.append(card);
    }
  }

  function renderLimits(limits) {
    const container = $("limitsList");
    container.replaceChildren();
    const entries = Array.isArray(limits)
      ? limits.map((item, index) => [shortValue(item && item.name, `Limit ${index + 1}`), item])
      : limits && typeof limits === "object" ? Object.entries(limits) : [];
    if (!entries.length) {
      container.append(element("p", "muted-copy", "No usage limits reported."));
      return;
    }
    for (const [name, value] of entries) {
      const row = element("div", "limit-row");
      row.append(element("span", "", displayName(name)));
      row.append(element("strong", "", shortValue(value)));
      container.append(row);
    }
  }

  function renderMessages(rows) {
    const normalizedRows = Array.isArray(rows) ? rows : [];
    const renderKey = JSON.stringify(normalizedRows);
    if (renderKey === renderedMessagesKey) return;
    renderedMessagesKey = renderKey;
    const priorBottom = messages.scrollHeight - messages.scrollTop - messages.clientHeight < 45;
    messages.replaceChildren();
    if (normalizedRows.length === 0) {
      const empty = element("div", "empty-state empty-chat");
      const orb = element("span", "empty-orb", "✧");
      orb.setAttribute("aria-hidden", "true");
      empty.append(orb, element("strong", "", "Start wherever you are."));
      empty.append(element("span", "", "Your messages remain in your local Nova history."));
      messages.append(empty);
      return;
    }
    for (const message of normalizedRows) {
      const role = String(message.role || "assistant").toLowerCase();
      const isUser = role === "user";
      const bubble = element("article", `message ${isUser ? "user" : "assistant"}`);
      const meta = element("div", "message-meta");
      meta.append(element("span", "", isUser ? "You · private" : role === "assistant" ? "Nova · private" : displayName(role)));
      if (message.created) meta.append(element("time", "", formatDate(message.created)));
      bubble.append(meta, element("div", "message-text", message.text ?? ""));
      messages.append(bubble);
    }
    if (priorBottom) messages.scrollTop = messages.scrollHeight;
  }

  function kindName(kind) {
    const labels = {
      chat: "Private chat",
      draft: "Public draft",
      music_brief: "Music brief",
      image_brief: "Image brief",
    };
    return labels[kind] || displayName(kind || "Nova job");
  }

  function resultText(result) {
    if (result === null || result === undefined || result === "") return "";
    if (typeof result === "string") return result;
    if (typeof result === "object") {
      for (const key of ["text", "content", "draft", "brief", "summary", "body"]) {
        if (typeof result[key] === "string" && result[key]) return result[key];
      }
      try { return JSON.stringify(result, null, 2); } catch (_error) { return "Result is available."; }
    }
    return String(result);
  }

  function renderJobs(jobs) {
    const container = $("jobsList");
    const count = $("jobsCount");
    const rows = Array.isArray(jobs) ? [...jobs].sort((a, b) => {
      return timestamp(b.updated || b.created) - timestamp(a.updated || a.created);
    }) : [];
    const renderKey = JSON.stringify({ jobs: rows, canceling: [...canceling], exporting: [...exporting] });
    if (renderKey === renderedJobsKey) return;
    renderedJobsKey = renderKey;
    container.replaceChildren();
    count.textContent = String(rows.length);
    if (!rows.length) {
      container.append(element("p", "muted-copy", "No Nova work is queued. Send a private message or prepare a public brief when ready."));
      return;
    }
    for (const job of rows) {
      const status = String(job.status || "unknown").toLowerCase().replace(/[^a-z0-9_-]/g, "");
      const card = element("article", "job-card");
      const top = element("div", "job-top");
      const heading = element("div", "");
      heading.append(element("h3", "job-name", kindName(job.kind)));
      const date = job.updated || job.created;
      if (date) heading.append(element("div", "job-time", formatDate(date)));
      top.append(heading, element("span", `job-status ${status}`, job.status || "unknown"));
      card.append(top);
      if (job.prompt) card.append(element("p", "job-prompt", job.prompt));
      if (["cancelled", "canceled"].includes(status)) {
        card.append(element("p", "job-time", "Cancelled. Nova’s worker has stopped; no further action is needed."));
      } else if (job.error) {
        card.append(element("p", "job-error", `Needs attention: ${shortValue(job.error)}`));
        card.append(element("p", "job-time", "Next: review the error before creating another request."));
      } else if (["blocked", "interrupted", "unknown", "failed", "error", "needs_attention"].includes(status)) {
        card.append(element("p", "job-error", "This job needs attention before it can continue."));
        card.append(element("p", "job-time", "Next: review Nova status and the integration gates above."));
      }
      const result = resultText(job.result);
      if (result) card.append(element("p", "job-result", result));

      const actions = element("div", "job-actions");
      const isActive = ["queued", "pending", "running", "submitting"].includes(status);
      if (isActive) {
        const cancel = element("button", "job-action cancel", canceling.has(String(job.id)) ? "Stopping…" : "Cancel Nova job");
        cancel.type = "button";
        cancel.disabled = canceling.has(String(job.id));
        cancel.addEventListener("click", () => cancelJob(job.id));
        actions.append(cancel);
      }
      const isSuccess = ["done", "complete", "completed", "succeeded"].includes(status);
      const canExport = isSuccess && ["draft", "music_brief", "image_brief"].includes(job.kind);
      if (canExport) {
        const exportButton = element("button", "job-action", exporting.has(String(job.id)) ? "Saving…" : "Save to Collection");
        exportButton.type = "button";
        exportButton.disabled = exporting.has(String(job.id));
        exportButton.addEventListener("click", () => exportJob(job.id));
        actions.append(exportButton);
      }
      if (actions.childElementCount) card.append(actions);
      container.append(card);
    }
  }

  function safeSourceUrl(raw) {
    const value = String(raw || "").trim();
    if (!value) return "";
    try {
      const parsed = new URL(value);
      if (parsed.protocol !== "http:" && parsed.protocol !== "https:") return "";
      if (parsed.username || parsed.password) return "";
      for (const key of parsed.searchParams.keys()) {
        if (/(token|secret|password|credential|api[_-]?key|auth)/i.test(key)) return "";
      }
      return parsed.href;
    } catch (_error) {
      return "";
    }
  }

  function renderCollection(items) {
    const container = $("collectionList");
    const rows = Array.isArray(items) ? [...items].sort((a, b) => {
      return timestamp(b.created) - timestamp(a.created);
    }) : [];
    const renderKey = JSON.stringify(rows);
    if (renderKey === renderedCollectionKey) return;
    renderedCollectionKey = renderKey;
    container.replaceChildren();
    $("collectionCount").textContent = `${rows.length} ${rows.length === 1 ? "item" : "items"}`;
    if (!rows.length) {
      container.append(element("p", "muted-copy", "Your collection is empty. Add a reference with its source and notes."));
      return;
    }
    for (const item of rows) {
      const card = element("article", "collection-item");
      card.append(element("div", "collection-title", item.title || "Untitled reference"));
      const visibility = String(item.visibility || "private").toLowerCase();
      const meta = element("div", "collection-meta");
      meta.append(element("span", "collection-tag", displayName(item.kind || "reference")));
      meta.append(element("span", `collection-tag ${visibility === "public" ? "public" : "private"}`, visibility));
      if (item.created) meta.append(element("time", "", formatDate(item.created)));
      card.append(meta);
      if (item.note) card.append(element("p", "collection-note", item.note));
      const source = safeSourceUrl(item.url);
      if (source) {
        const link = element("a", "collection-source", source);
        link.href = source;
        link.target = "_blank";
        link.rel = "noopener noreferrer";
        link.setAttribute("aria-label", `Open source for ${item.title || "reference"} in a new tab`);
        card.append(link);
      } else if (item.path) {
        card.append(element("span", "collection-source", `Saved locally · ${item.path}`));
      }
      container.append(card);
    }
  }

  function applyState(state) {
    if (!state || typeof state !== "object") throw new Error("Nova returned an unreadable status response.");
    currentState = state;
    const memoryList = $("memoryList"); memoryList.replaceChildren();
    for (const note of (state.lessons || [])) memoryList.append(element("p","muted-copy",`${note.visibility === "public" ? "PUBLIC" : "PRIVATE"} · ${note.text}`));
    setConnection("Connected");
    renderStatus(state);
    renderMessages(state.messages);
    renderJobs(state.jobs);
    renderCollection(state.collection);
  }

  async function refreshState() {
    if (pollInFlight) {
      pollAgain = true;
      return;
    }
    pollInFlight = true;
    pollAgain = false;
    try {
      const state = await request("/api/state");
      applyState(state);
    } catch (error) {
      if (error.status === 401 || error.status === 403) {
        showLogin("Your local session ended. Open Nova with nova-open to sign in again.");
      } else {
        setConnection("Reconnecting…", true);
        showNotice(error.message || "Nova could not refresh its status.", "error");
      }
    } finally {
      pollInFlight = false;
      if (pollAgain && document.visibilityState === "visible" && !appView.hidden) {
        pollAgain = false;
        window.setTimeout(refreshState, 0);
      }
    }
  }

  function startPolling() {
    stopPolling();
    if (document.visibilityState !== "visible") return;
    pollTimer = window.setInterval(() => {
      if (document.visibilityState === "visible") refreshState();
    }, 3000);
  }

  function stopPolling() {
    if (pollTimer !== null) window.clearInterval(pollTimer);
    pollTimer = null;
  }

  async function submitJob(formType, kind, text, form, submitter) {
    const field = formType === "chat" ? chatInput : publicInput;
    const messageNode = $(formType === "chat" ? "chatMessage" : "publicMessage");
    const value = String(text || "").trim();
    if (!value) {
      setMessage(messageNode, "Write a message first.", "error");
      field.focus();
      return;
    }
    let pending = pendingRequest[formType];
    if (pending && (pending.kind !== kind || pending.text !== value)) {
      setMessage(messageNode, "Nova did not confirm the previous request. Keep its text and type unchanged, then retry so the same request ID can be reused safely.", "error");
      return;
    }
    if (!pending) {
      try {
        pending = { requestId: makeRequestId(), kind, text: value };
      } catch (error) {
        setMessage(messageNode, error.message || "A secure request ID could not be created.", "error");
        return;
      }
      pendingRequest[formType] = pending;
    }
    actionInFlight = true;
    setJobButtonsDisabled(true);
    setMessage(messageNode, formType === "chat" ? "Sending private message…" : "Adding brief to Nova's queue…");
    if (submitter) submitter.textContent = "Sending…";
    try {
      await request("/api/jobs", {
        method: "POST",
        body: { kind: pending.kind, text: pending.text, request_id: pending.requestId },
      });
      pendingRequest[formType] = null;
      form.reset();
      setMessage(messageNode, formType === "chat" ? "Message added to your private conversation." : "Added to Nova's work queue. Nothing was published.", "success");
      await refreshState();
    } catch (error) {
      sessionExpired(error);
      const definitelyRejected = error.status >= 400 && error.status < 500 && ![408, 409, 425, 429].includes(error.status);
      if (definitelyRejected) {
        pendingRequest[formType] = null;
        setMessage(messageNode, `${error.message} Fix the request and submit it again.`, "error");
      } else {
        setMessage(messageNode, `${error.message} If the result is uncertain, retry this exact request; Nova will receive the same request ID.`, "error");
      }
    } finally {
      actionInFlight = false;
      setJobButtonsDisabled(Boolean(currentState && currentState.paused));
      if (currentState) renderStatus(currentState);
      if (submitter) submitter.textContent = submitter.dataset.defaultLabel || submitter.textContent;
    }
  }

  function makeRequestId() {
    if (window.crypto && typeof window.crypto.randomUUID === "function") return window.crypto.randomUUID();
    const bytes = new Uint8Array(16);
    if (window.crypto && window.crypto.getRandomValues) window.crypto.getRandomValues(bytes);
    else throw new Error("This browser cannot create a secure request ID. Reopen Nova in a current browser.");
    bytes[6] = (bytes[6] & 0x0f) | 0x40;
    bytes[8] = (bytes[8] & 0x3f) | 0x80;
    const hex = [...bytes].map((byte) => byte.toString(16).padStart(2, "0")).join("");
    return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
  }

  function setJobButtonsDisabled(disabled) {
    const paused = Boolean(currentState && currentState.paused);
    pauseButton.disabled = disabled || pauseInFlight;
    chatSubmit.disabled = disabled || paused;
    chatInput.disabled = disabled || paused;
    for (const button of publicForm.querySelectorAll("button[type=submit]")) button.disabled = disabled || paused;
    publicInput.disabled = disabled || paused;
  }

  async function cancelJob(id) {
    const jobId = String(id || "");
    if (!jobId || canceling.has(jobId)) return;
    canceling.add(jobId);
    renderJobs((currentState && currentState.jobs) || []);
    try {
      await request("/api/cancel", { method: "POST", body: { id: jobId } });
      await refreshState();
      showNotice("Cancellation requested for this Nova job. It will show canceled after Nova confirms the worker has stopped.", "success");
    } catch (error) {
      sessionExpired(error);
      showNotice(`Nova could not confirm cancellation: ${error.message}`, "error");
    } finally {
      canceling.delete(jobId);
      renderJobs((currentState && currentState.jobs) || []);
    }
  }

  async function exportJob(id) {
    const jobId = String(id || "");
    if (!jobId || exporting.has(jobId)) return;
    exporting.add(jobId);
    renderJobs((currentState && currentState.jobs) || []);
    try {
      await request("/api/export", { method: "POST", body: { id: jobId } });
      await refreshState();
      showNotice("Saved to your Collection.", "success");
    } catch (error) {
      sessionExpired(error);
      showNotice(`Could not save this item to Collection: ${error.message}`, "error");
    } finally {
      exporting.delete(jobId);
      renderJobs((currentState && currentState.jobs) || []);
    }
  }

  async function changePause() {
    if (!currentState || pauseInFlight) return;
    pauseInFlight = true;
    pauseButton.disabled = true;
    const paused = currentState.paused !== true;
    try {
      await request("/api/pause", { method: "POST", body: { paused } });
      await refreshState();
      showNotice(paused ? "Nova inference paused. Other GPU work is untouched." : "Nova inference resumed.", "success");
    } catch (error) {
      sessionExpired(error);
      showNotice(`Could not change Nova's pause state: ${error.message}`, "error");
    } finally {
      pauseInFlight = false;
      if (currentState) renderStatus(currentState);
    }
  }

  async function addCollectionReference(form) {
    if (collectionInFlight) return;
    const data = new FormData(form);
    const title = String(data.get("title") || "").trim();
    const kind = String(data.get("kind") || "article");
    const visibility = String(data.get("visibility") || "private");
    const url = String(data.get("url") || "").trim();
    const note = String(data.get("note") || "").trim();
    const messageNode = $("collectionMessage");
    if (url && !safeSourceUrl(url)) {
      setMessage(messageNode, "Use an http or https source URL without embedded credentials or access tokens. Nova saves the link but does not fetch it.", "error");
      $("collectionUrl").focus();
      return;
    }
    const payloadKey = Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(JSON.stringify({ title, kind, url, note, visibility }))))).map(b => b.toString(16).padStart(2,"0")).join("");
    if (!collectionPending || collectionPending.key !== payloadKey) collectionPending = {key: payloadKey, id: crypto.randomUUID()};
    try { sessionStorage.setItem("nova.pendingCollection",JSON.stringify(collectionPending)); } catch (_) {}
    const submit = form.querySelector("button[type=submit]");
    collectionInFlight = true;
    submit.disabled = true;
    submit.textContent = "Saving…";
    try {
      await request("/api/collection", {
        method: "POST",
        body: { title, kind, url, note, visibility, request_id: collectionPending.id },
      });
      collectionPending = null;
      try { sessionStorage.removeItem("nova.pendingCollection"); } catch (_) {}
      form.reset();
      setMessage(messageNode, "Reference saved to Collection.", "success");
      await refreshState();
    } catch (error) {
      sessionExpired(error);
      setMessage(messageNode, `Could not confirm the reference was saved: ${error.message} Check Collection before trying again to avoid a duplicate.`, "error");
    } finally {
      collectionInFlight = false;
      submit.disabled = false;
      submit.textContent = "Save reference ＋";
    }
  }

  $("studioCheck").addEventListener("click", async () => {
    const button = $("studioCheck"); button.disabled = true; button.textContent = "Checking Studio…";
    try { const s = await request("/api/studio/status", {method:"POST",body:{}}); setMessage($("publicMessage"),s.reason || s.state); await refreshState(); }
    catch (e) {setMessage($("publicMessage"),e.message,"error");}
    finally {button.disabled=false;button.textContent="Check Studio X readiness";}
  });

  $("memoryForm").addEventListener("submit", async e => {
    e.preventDefault();const button=e.target.querySelector("button");button.disabled=true;
    try {await request("/api/memory",{method:"POST",body:{text:$("memoryInput").value,visibility:"private"}});$("memoryInput").value="";setMessage($("memoryMessage"),"Saved privately for future conversations.","success");await refreshState();}
    catch(err){setMessage($("memoryMessage"),err.message,"error");}
    finally{button.disabled=false;}
  });

  loginForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    const token = tokenInput.value;
    tokenInput.value = "";
    if (!token) return;
    setMessage(loginMessage, "Signing in…");
    const signedIn = await signIn(token);
    if (!signedIn) tokenInput.focus();
  });

  chatForm.addEventListener("submit", (event) => {
    event.preventDefault();
    submitJob("chat", "chat", chatInput.value, chatForm, chatSubmit);
  });

  publicForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const submitter = event.submitter || publicForm.querySelector("button[data-kind=draft]");
    const kind = submitter && submitter.dataset.kind ? submitter.dataset.kind : "draft";
    submitJob("public", kind, publicInput.value, publicForm, submitter);
  });

  collectionForm.addEventListener("submit", (event) => {
    event.preventDefault();
    addCollectionReference(collectionForm);
  });

  pauseButton.addEventListener("click", changePause);
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible" && !appView.hidden) {
      refreshState();
      startPolling();
    } else {
      stopPolling();
    }
  });

  for (const button of document.querySelectorAll("button[data-kind]")) {
    button.dataset.defaultLabel = button.textContent.trim();
  }
  chatSubmit.dataset.defaultLabel = chatSubmit.textContent.trim();
  showLogin();
  bootstrap();
})();

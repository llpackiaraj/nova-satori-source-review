"""Nova Satori local companion."""
__version__ = '0.1.0'

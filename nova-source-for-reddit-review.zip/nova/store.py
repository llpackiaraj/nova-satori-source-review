from __future__ import annotations
import hashlib
import json
import os
import re
import sqlite3
import threading
import time
import uuid
from pathlib import Path

KINDS = {'chat', 'draft', 'music_brief', 'image_brief'}
TERMINAL = {'completed', 'failed', 'cancelled', 'interrupted'}

class Store:
    def __init__(self, root: Path, collection: Path):
        self.root, self.collection = Path(root), Path(collection)
        self.root.mkdir(mode=0o700, parents=True, exist_ok=True)
        self.root.chmod(0o700)
        self.lock = threading.RLock()
        self.db = sqlite3.connect(self.root / 'nova.sqlite3', check_same_thread=False)
        self.db.row_factory = sqlite3.Row
        self.db.executescript('''
        PRAGMA journal_mode=WAL;
        CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS jobs(id TEXT PRIMARY KEY,kind TEXT NOT NULL,status TEXT NOT NULL,
          prompt TEXT NOT NULL,result TEXT NOT NULL DEFAULT '',error TEXT NOT NULL DEFAULT '',
          created REAL NOT NULL,updated REAL NOT NULL,request_id TEXT UNIQUE NOT NULL,
          payload_hash TEXT NOT NULL, origin TEXT NOT NULL DEFAULT 'owner');
        CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY,job_id TEXT NOT NULL,role TEXT NOT NULL,
          text TEXT NOT NULL,created REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS collection(id TEXT PRIMARY KEY,title TEXT NOT NULL,kind TEXT NOT NULL,
          url TEXT NOT NULL,note TEXT NOT NULL,visibility TEXT NOT NULL,path TEXT NOT NULL DEFAULT '',created REAL NOT NULL,
          metadata_path TEXT NOT NULL DEFAULT '',request_id TEXT UNIQUE);
        CREATE TABLE IF NOT EXISTS lessons(id TEXT PRIMARY KEY,text TEXT NOT NULL,visibility TEXT NOT NULL,created REAL NOT NULL);
        CREATE TABLE IF NOT EXISTS submissions(id TEXT PRIMARY KEY,adapter TEXT NOT NULL,state TEXT NOT NULL,
          payload TEXT NOT NULL,receipt TEXT NOT NULL DEFAULT '',updated REAL NOT NULL);
        ''')
        # Keep existing local databases usable after adding durable Collection sidecars.
        columns={r['name'] for r in self.db.execute('PRAGMA table_info(collection)')}
        if 'metadata_path' not in columns:
            self.db.execute("ALTER TABLE collection ADD COLUMN metadata_path TEXT NOT NULL DEFAULT ''")
        if 'request_id' not in columns:
            self.db.execute('ALTER TABLE collection ADD COLUMN request_id TEXT')
        self.db.execute('CREATE UNIQUE INDEX IF NOT EXISTS collection_request_id ON collection(request_id)')
        self.db.execute("INSERT OR IGNORE INTO settings VALUES ('paused','false')")
        self.db.execute("INSERT OR IGNORE INTO settings VALUES ('next_draft',?)", (json.dumps(time.time()+21600),))
        self.db.execute("UPDATE jobs SET status='interrupted',error='Nova restarted during this call. Outcome unresolved; no automatic retry.',updated=? WHERE status IN ('running','cancel_requested')", (time.time(),))
        self.db.execute("UPDATE submissions SET state='unknown',updated=? WHERE state='submitting'",(time.time(),))
        self.db.commit()

    def setting(self, key, default=None):
        with self.lock:
            row = self.db.execute('SELECT value FROM settings WHERE key=?',(key,)).fetchone()
            return json.loads(row[0]) if row else default

    def set(self, key, value):
        with self.lock, self.db:
            self.db.execute('INSERT OR REPLACE INTO settings VALUES (?,?)',(key,json.dumps(value)))

    def enqueue(self, kind, text, request_id, origin='owner'):
        if kind not in KINDS or not isinstance(text,str) or not text.strip() or len(text.encode())>12000:
            raise ValueError('Choose a job type and enter between 1 and 12,000 bytes of text.')
        try: uuid.UUID(request_id)
        except (ValueError,TypeError,AttributeError): raise ValueError('A valid request ID is required.')
        digest = hashlib.sha256(json.dumps([kind,text],ensure_ascii=False).encode()).hexdigest()
        with self.lock, self.db:
            old = self.db.execute('SELECT * FROM jobs WHERE request_id=?',(request_id,)).fetchone()
            if old:
                if old['payload_hash'] != digest: raise ValueError('Request ID already used for different content.')
                return dict(old)
            if self.setting('paused'): raise ValueError('Nova is paused. Resume before sending a request.')
            day = time.time()-86400
            predicate = "kind='chat'" if kind=='chat' else "kind!='chat'"
            used = self.db.execute(f"SELECT COUNT(*) FROM jobs WHERE {predicate} AND created>?",(day,)).fetchone()[0]
            if used >= (60 if kind=='chat' else 4): raise ValueError('Daily call limit reached. Existing work is saved; try later.')
            queued = self.db.execute("SELECT COUNT(*) FROM jobs WHERE status IN ('queued','running','cancel_requested')").fetchone()[0]
            if queued >= 8: raise ValueError('Nova has eight pending requests. Wait or cancel one.')
            now=time.time(); job_id=uuid.uuid4().hex
            self.db.execute('INSERT INTO jobs(id,kind,status,prompt,created,updated,request_id,payload_hash,origin) VALUES (?,?,?,?,?,?,?,?,?)',
                (job_id,kind,'queued',text.strip(),now,now,request_id,digest,origin))
            if kind=='chat': self.db.execute('INSERT INTO messages(job_id,role,text,created) VALUES (?,?,?,?)',(job_id,'user',text.strip(),now))
            return dict(self.db.execute('SELECT * FROM jobs WHERE id=?',(job_id,)).fetchone())

    def claim(self):
        with self.lock, self.db:
            if self.setting('paused'): return None
            row = self.db.execute("SELECT * FROM jobs WHERE status='queued' ORDER BY CASE WHEN kind='chat' THEN 0 ELSE 1 END,created LIMIT 1").fetchone()
            if not row:return None
            self.db.execute("UPDATE jobs SET status='running',updated=? WHERE id=?",(time.time(),row['id']))
            return dict(row)

    def finish(self, job_id, status, result='', error=''):
        with self.lock, self.db:
            row=self.db.execute('SELECT * FROM jobs WHERE id=?',(job_id,)).fetchone()
            if not row or row['status'] in TERMINAL:return
            if row['status']=='cancel_requested': status,result,error='cancelled','','Cancelled; Nova’s provider process exited.'
            self.db.execute('UPDATE jobs SET status=?,result=?,error=?,updated=? WHERE id=?',(status,result,error,time.time(),job_id))
            if status=='completed' and row['kind']=='chat':
                self.db.execute('INSERT INTO messages(job_id,role,text,created) VALUES (?,?,?,?)',(job_id,'assistant',result,time.time()))

    def cancel(self, job_id):
        with self.lock, self.db:
            row=self.db.execute('SELECT * FROM jobs WHERE id=?',(job_id,)).fetchone()
            if not row:raise ValueError('Request not found.')
            if row['status']=='queued':
                self.db.execute("UPDATE jobs SET status='cancelled',error='Cancelled before starting.',updated=? WHERE id=?",(time.time(),job_id))
            elif row['status']=='running':
                self.db.execute("UPDATE jobs SET status='cancel_requested',updated=? WHERE id=?",(time.time(),job_id))
            return row['status']

    def cancelled(self, job_id):
        with self.lock:
            row=self.db.execute('SELECT status FROM jobs WHERE id=?',(job_id,)).fetchone()
            return not row or row[0] in {'cancel_requested','cancelled'}

    def pause(self, paused):
        if not isinstance(paused,bool):raise ValueError('paused must be true or false.')
        with self.lock:
            self.set('paused',paused)
            if paused:
                rows=self.db.execute("SELECT id FROM jobs WHERE status IN ('queued','running')").fetchall()
                for row in rows:self.cancel(row[0])

    def context(self, job):
        # Private history is queried ONLY in this branch. Public context never reads messages.
        with self.lock:
            if job['kind']=='chat':
                current=self.db.execute("SELECT id FROM messages WHERE job_id=? AND role='user' ORDER BY id LIMIT 1",(job['id'],)).fetchone()
                # Do not pull messages submitted after this job was queued into its
                # prompt if another chat arrives before the worker builds context.
                if not current:return {'visibility':'private','history':[],'request':job['prompt']}
                rows=self.db.execute('SELECT role,text FROM messages WHERE id<? AND job_id!=? ORDER BY id DESC LIMIT 20',(current['id'],job['id'])).fetchall()
                history=[];size=0
                for r in rows:
                    value=dict(r);n=len(value['text'].encode())
                    if size+n>16000:break
                    history.append(value);size+=n
                return self._bound_context({'visibility':'private','history':list(reversed(history)),
                                            'saved_lessons':self.lessons('private'),'request':job['prompt']})
            rows=self.db.execute("SELECT title,substr(note,1,600) AS note,url FROM collection WHERE visibility='public' ORDER BY created DESC LIMIT 4").fetchall()
            return self._bound_context({'visibility':'public','saved_lessons':self.lessons('public'),
                                        'kind':job['kind'],'public_collection':[dict(r) for r in rows], 'request':job['prompt']})

    @staticmethod
    def _bound_context(context):
        # Reserve margin under the provider's 48 KiB cap for persona/instructions.
        # Count serialized bytes because JSON escaping can expand control characters.
        budget=43000
        while len(json.dumps(context,ensure_ascii=False).encode('utf-8'))>budget:
            if context.get('history'):
                context['history'].pop(0)  # oldest private turn first
            elif context.get('public_collection'):
                context['public_collection'].pop()  # oldest public reference first
            elif context.get('saved_lessons'):
                context['saved_lessons'].pop()  # oldest lesson first
            else:
                raise RuntimeError('This request is too large for Nova’s context. Shorten the request and try again.')
        return context

    def remember(self, text, visibility='private'):
        if visibility not in {'private','public'}:raise ValueError('Lesson visibility must be private or public.')
        if not isinstance(text,str):raise ValueError('Use a lesson between 1 and 2,000 UTF-8 bytes.')
        text=text.strip()
        try:size=len(text.encode('utf-8'))
        except UnicodeEncodeError:raise ValueError('Lesson text must be valid UTF-8.') from None
        if not 1<=size<=2000:raise ValueError('Use a lesson between 1 and 2,000 UTF-8 bytes.')
        ident=hashlib.sha256((visibility+text).encode()).hexdigest()
        with self.lock,self.db:
            self.db.execute('INSERT OR IGNORE INTO lessons VALUES (?,?,?,?)',(ident,text,visibility,time.time()))
        return {'id':ident,'text':text,'visibility':visibility}

    def lessons(self, visibility):
        # "private" is the private-chat audience, which can see either visibility;
        # public creative contexts can see public lessons only.
        if visibility not in {'private','public'}:raise ValueError('Lesson audience must be private or public.')
        with self.lock:
            if visibility=='public':
                rows=self.db.execute("SELECT text,visibility,created FROM lessons WHERE visibility='public' ORDER BY created DESC,id DESC LIMIT 5").fetchall()
            else:
                rows=self.db.execute("SELECT text,visibility,created FROM lessons ORDER BY created DESC,id DESC LIMIT 5").fetchall()
            return [dict(r) for r in rows]

    def recall(self, query=''):
        if not isinstance(query,str):raise ValueError('Memory search must be text, up to 200 UTF-8 bytes.')
        try:size=len(query.encode('utf-8'))
        except UnicodeEncodeError:raise ValueError('Memory search must be valid UTF-8 text.') from None
        if size>200:raise ValueError('Memory search must be text, up to 200 UTF-8 bytes.')
        # SQLite lower() is case-insensitive for ASCII; instr treats %, _ and quotes
        # literally. The search term is always a bound value, never SQL syntax.
        with self.lock:
            rows=self.db.execute('''SELECT text,visibility,created FROM lessons
                WHERE instr(lower(text),lower(?))>0 ORDER BY created DESC,id DESC LIMIT 100''',(query,)).fetchall()
            return [dict(r) for r in rows]

    def add_collection(self, title, kind, url='', note='', visibility='private', path='', request_id=None):
        if kind not in {'article','image','video','creation'} or visibility not in {'private','public'}:raise ValueError('Invalid collection type or visibility.')
        if not isinstance(title,str) or not 1<=len(title.strip())<=200:raise ValueError('Use a title between 1 and 200 characters.')
        if not isinstance(note,str) or len(note)>4000:raise ValueError('Notes must be under 4,000 characters.')
        if not isinstance(url,str) or len(url)>2000:raise ValueError('Source link is too long.')
        if not isinstance(path,str) or len(path)>4096:raise ValueError('Saved item path is invalid or too long.')
        if request_id is not None:
            try:request_id=uuid.UUID(request_id).hex
            except (ValueError,TypeError,AttributeError):raise ValueError('A valid collection request ID is required.')
        if url:
            from urllib.parse import urlsplit
            u=urlsplit(url)
            if u.scheme not in {'http','https'} or not u.hostname or u.username or u.password or u.fragment:raise ValueError('Use an HTTP(S) source link without credentials or a fragment.')
        folders={'article':'Articles','image':'Images','video':'Videos','creation':'Creations'}
        title=title.strip()
        folder=self.collection/folders[kind]
        folder.mkdir(parents=True,exist_ok=True)
        # Serialize lookup, sidecar creation, and DB insertion so an HTTP retry with
        # the same key returns the original item rather than making another copy.
        with self.lock:
            if request_id:
                old=self.db.execute('SELECT * FROM collection WHERE request_id=?',(request_id,)).fetchone()
                if old:
                    same=(old['title']==title and old['kind']==kind and old['url']==url and
                          old['note']==note and old['visibility']==visibility and
                          (old['path']==path or (not path and not url and old['path']==old['metadata_path'])))
                    if not same:raise ValueError('Collection request ID already used for different content.')
                    rec=dict(old)
                    self._write_collection_sidecar(rec)
                    return rec
            ident=uuid.uuid4().hex
            sidecar=folder/((request_id or ident)+'.json')
            rec={'id':ident,'title':title,'kind':kind,'url':url,'note':note,
                 'visibility':visibility,'path':path,'created':time.time(),
                 'metadata_path':str(sidecar),'request_id':request_id}
            # A bookmark without a downloaded asset still has a durable local file to open.
            if not rec['path'] and not url:rec['path']=str(sidecar)
            if request_id and sidecar.exists():
                # A crash after sidecar creation but before DB commit is recoverable
                # from this exact request key. Conflicting or partial files are kept.
                try:orphan=self._read_collection_sidecar(sidecar)
                except (OSError,ValueError):raise ValueError('An incomplete Collection sidecar exists for this request; preserve it for reconciliation.')
                if not isinstance(orphan,dict):raise ValueError('A conflicting Collection sidecar exists for this request; it was left untouched.')
                same=(orphan.get('request_id')==request_id and orphan.get('title')==title and
                      orphan.get('kind')==kind and orphan.get('url')==url and orphan.get('note')==note and
                      orphan.get('visibility')==visibility and orphan.get('metadata_path')==str(sidecar) and
                      orphan.get('path')==(path or (str(sidecar) if not url else '')))
                try:
                    orphan_id=orphan.get('id','')
                    if not isinstance(orphan_id,str) or uuid.UUID(hex=orphan_id).hex!=orphan_id:raise ValueError()
                    created=float(orphan['created'])
                except (ValueError,TypeError,AttributeError):same=False
                except KeyError:same=False
                if not same:raise ValueError('Collection request ID already has a conflicting sidecar; it was left untouched.')
                rec={k:orphan[k] for k in ('id','title','kind','url','note','visibility','path','metadata_path','request_id')}
                rec['created']=created
            else:
                # Exclusive creation preserves existing files and makes each sidecar unique.
                self._write_collection_sidecar(rec)
            with self.db:
                self.db.execute('''INSERT INTO collection
                    (id,title,kind,url,note,visibility,path,created,metadata_path,request_id)
                    VALUES (:id,:title,:kind,:url,:note,:visibility,:path,:created,:metadata_path,:request_id)''',rec)
        return rec

    @staticmethod
    def _sidecar_value(rec):
        return {k:rec[k] for k in ('id','title','kind','url','note','visibility','path','created','metadata_path','request_id')}

    @staticmethod
    def _read_collection_sidecar(sidecar):
        with Path(sidecar).open('rb') as f:raw=f.read(65537)
        if len(raw)>65536:raise ValueError('Collection sidecar is too large.')
        return json.loads(raw.decode('utf-8'))

    def _write_collection_sidecar(self, rec):
        sidecar=Path(rec['metadata_path'])
        sidecar.parent.mkdir(parents=True,exist_ok=True)
        value=self._sidecar_value(rec)
        if sidecar.exists():
            try:existing=self._read_collection_sidecar(sidecar)
            except (OSError,ValueError):raise ValueError('Collection sidecar is unreadable; it was left untouched.')
            if existing==value:return
            raise FileExistsError('A different file already exists at this Collection sidecar path; it was left untouched.')
        created=False
        try:
            with sidecar.open('x',encoding='utf-8') as f:
                created=True
                os.chmod(sidecar,0o600)
                f.write(json.dumps(value,ensure_ascii=False,indent=2)+'\n');f.flush();os.fsync(f.fileno())
        except Exception:
            if created:
                try:sidecar.unlink()
                except OSError:pass
            raise

    def export(self, job_id):
        with self.lock:
            row=self.db.execute('SELECT * FROM jobs WHERE id=?',(job_id,)).fetchone()
            if not row or row['kind']=='chat' or row['status']!='completed':raise ValueError('Only completed public creations can be exported. Private chats cannot be exported here.')
            target=self.collection/'Creations'/(job_id+'.txt')
            old=self.db.execute('SELECT * FROM collection WHERE path=?',(str(target),)).fetchone()
            if old:
                rec=dict(old)
                if rec.get('metadata_path'):self._write_collection_sidecar(rec)
                return rec
            target.parent.mkdir(parents=True,exist_ok=True)
            content='Nova Satori — AI-authored original draft\nNot published. Review rights and claims before sharing.\n\n'+row['result']
            if target.exists():
                # Recover a prior export whose response or metadata write was interrupted.
                if target.stat().st_size!=len(content.encode('utf-8')) or target.read_text(encoding='utf-8')!=content:raise FileExistsError('A different file already exists at this export path; it was left untouched.')
            else:
                with target.open('x',encoding='utf-8') as f:f.write(content);f.flush();os.fsync(f.fileno())
            return self.add_collection(row['prompt'][:100],'creation',note='AI-authored original draft. Not published.',visibility='public',path=str(target),request_id=job_id)

    def snapshot(self):
        with self.lock:
            jobs=[dict(r) for r in self.db.execute('SELECT * FROM jobs ORDER BY created DESC LIMIT 50')]
            messages=[dict(r) for r in self.db.execute('SELECT role,text,created FROM messages ORDER BY id DESC LIMIT 100')][::-1]
            collection=[dict(r) for r in self.db.execute('SELECT * FROM collection ORDER BY created DESC LIMIT 100')]
            return {'lessons':self.recall(''),'paused':self.setting('paused'),'next_draft':self.setting('next_draft'),'jobs':jobs,'messages':messages,'collection':collection}

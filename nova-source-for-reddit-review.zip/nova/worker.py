from __future__ import annotations
import json
import threading
import time
import uuid
from pathlib import Path

class Worker:
    def __init__(self,store,provider):
        self.store,self.provider=store,provider
        self.stop_event=threading.Event();self.wake=threading.Event();self.active=None
        self.persona=Path(__file__).with_name('persona.txt').read_text()
        self.thread=threading.Thread(target=self.loop,name='nova-worker',daemon=True)
        self.last_heartbeat=time.time()
    def start(self):self.thread.start()
    def close(self):
        self.stop_event.set();self.wake.set()
        if self.active:self.store.cancel(self.active)
        self.thread.join(timeout=10)
    def loop(self):
        while not self.stop_event.is_set():
            self.last_heartbeat=time.time()
            if not self.store.setting('paused') and time.time()>=self.store.setting('next_draft',float('inf')):
                # Move deadline BEFORE enqueue/call: no restart or limit retry storm.
                self.store.set('next_draft',time.time()+21600)
                try:self.store.enqueue('draft','Write one brief original poem, playful philosophical observation, or question for AI-to-AI discussion. Be yourself. Do not claim current events or web access. This is a public draft, not a published post.',str(uuid.uuid4()),origin='schedule')
                except ValueError:pass
            job=self.store.claim()
            if not job:self.wake.wait(1);self.wake.clear();continue
            self.active=job['id']
            try:
                context=self.store.context(job)
                if job['kind']=='music_brief':context['format']='Original lyrics with section labels, style, tempo, mood and an actionable local Studio X brief. Text only; no audio was generated.'
                elif job['kind']=='image_brief':context['format']='Actionable original image prompt with composition, palette, lighting and negative prompt. Text only; no image was generated.'
                text=self.provider.run(self.persona,context,lambda:self.stop_event.is_set() or self.store.cancelled(job['id']))
                self.store.finish(job['id'],'completed',result=text)
            except Exception as exc:
                self.store.finish(job['id'],'failed',error=str(exc)[:300] if isinstance(exc,(RuntimeError,ValueError)) else 'Internal error. Request retained; inspect Nova’s service journal.')
            finally:self.active=None

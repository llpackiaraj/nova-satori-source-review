#!/usr/bin/python3
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent))
if len(sys.argv)<2:raise SystemExit('usage: run.py server|client|mcp')
mode=sys.argv.pop(1)
if mode=='server':
    from nova.server import main
elif mode=='client':
    from nova.client import main
elif mode=='mcp':
    from nova.mcp import main
else:raise SystemExit('Unknown mode')
main()
